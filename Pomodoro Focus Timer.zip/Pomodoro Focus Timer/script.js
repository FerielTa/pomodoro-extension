let timerDisplay = document.getElementById("timer");
let startBtn = document.getElementById("startBtn");
let resetBtn = document.getElementById("resetBtn");

let duration = 25 * 60;
let current = duration;
let interval;

function updateDisplay() {
  let minutes = Math.floor(current / 60);
  let seconds = current % 60;
  timerDisplay.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

startBtn.onclick = () => {
  if (!interval) {
    interval = setInterval(() => {
      current--;
      updateDisplay();
      if (current <= 0) {
        clearInterval(interval);
        interval = null;
        chrome.notifications.create('', {
          type: 'basic',
          iconUrl: 'icon.png',
          title: 'الوقت انتهى!',
          message: 'خذ استراحة قصيرة ☕'
        });
      }
    }, 1000);
  }
};

resetBtn.onclick = () => {
  clearInterval(interval);
  interval = null;
  current = duration;
  updateDisplay();
};

updateDisplay();
startBtn.click();  // لتشغيل المؤقت تلقائيًا

