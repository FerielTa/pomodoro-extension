function showNotification() {
  const notificationId = 'notif_' + Date.now();

  chrome.notifications.create(notificationId, {
    type: 'basic',
    iconUrl: 'icon.png',
    title: '⏱️ انتهى المؤقت!',
    message: 'خذ استراحة الآن 🌿',
    priority: 2
  });
}

function startTimer() {
  setTimeout(() => {
    showNotification();
    startTimer(); // يعيد التشغيل بعد كل 25 دقيقة
  }, 1500000); // ⏱️ 25 دقيقة
}

chrome.runtime.onStartup.addListener(() => {
  startTimer();
});

chrome.runtime.onInstalled.addListener(() => {
  startTimer();
});
